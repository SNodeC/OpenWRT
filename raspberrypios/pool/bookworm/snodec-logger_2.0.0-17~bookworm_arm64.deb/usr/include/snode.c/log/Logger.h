/*
 * SNode.C - A Slim Toolkit for Network Communication
 * Copyright (C) Volker Christian <me@vchrist.at>
 *               2020, 2021, 2022, 2023, 2024, 2025, 2026
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * MIT License
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

#ifndef LOGGER_LOGGER_H
#define LOGGER_LOGGER_H

#ifndef DOXYGEN_SHOULD_SKIP_THIS

#include "log/SemanticLogger.h" // IWYU pragma: export

#include <functional>
#include <memory>
#include <ostream> // IWYU pragma: export
#include <string>

#endif /* DOXYGEN_SHOULD_SKIP_THIS */

namespace Color {

    enum class Code {
        FG_DEFAULT = 39,
        FG_BLACK = 30,
        FG_RED = 31,
        FG_GREEN = 32,
        FG_YELLOW = 33,
        FG_BLUE = 34,
        FG_MAGENTA = 35,
        FG_CYAN = 36,
        FG_LIGHT_GRAY = 37,
        FG_DARK_GRAY = 90,
        FG_LIGHT_RED = 91,
        FG_LIGHT_GREEN = 92,
        FG_LIGHT_YELLOW = 93,
        FG_LIGHT_BLUE = 94,
        FG_LIGHT_MAGENTA = 95,
        FG_LIGHT_CYAN = 96,
        FG_WHITE = 97,
        BG_RED = 41,
        BG_GREEN = 42,
        BG_BLUE = 44,
        BG_DEFAULT = 49
    };

    std::ostream& operator<<(std::ostream& os, const Code& code);

    std::string operator+(const std::string& string, const Code& code);
    std::string operator+(const Code& code, const std::string& string);

} // namespace Color

namespace logger {

    enum class Level { TRACE, DEBUG, INFO, WARNING, ERROR, FATAL, VERBOSE };

    class Logger {
    public:
        using TickResolver = std::function<std::string()>;

        Logger() = delete;
        ~Logger() = delete;

        static void init();
        static void defer();
        static void startAsync();
        static void shutdown();
        static void discardPending();
        static void setLogLevel(int level);
        static void setVerboseLevel(int level);
        static void logToFile(const std::string& logFile);
        static void disableLogToFile();
        static void setQuiet(bool quiet = true);
        static void setTickResolver(TickResolver resolver);
        static void setDisableColor(bool disableColorLog = true);
        static bool getDisableColor();
        static bool semanticStdoutUsesColor();

        static bool shouldLog(Level level);
        static bool shouldVerbose(int verboseLevel);

        static void emitSemantic(const LogRecord& record);
        static BoundaryLogger::Sink semanticSink();

    protected:
        static bool disableColorLog;

        friend std::ostream& Color::operator<<(std::ostream& os, const Color::Code& code);
        friend std::string Color::operator+(const std::string& string, const Color::Code& code);
        friend std::string Color::operator+(const Color::Code& code, const std::string& string);
    };

} // namespace logger

#endif // LOGGER_LOGGER_H
