/*
 * SNode.C - A Slim Toolkit for Network Communication
 * Copyright (C) Volker Christian <me@vchrist.at>
 *               2020, 2021, 2022, 2023, 2024, 2025, 2026
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * MIT License
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

#ifndef LOGGER_SEMANTICLOGGER_H
#define LOGGER_SEMANTICLOGGER_H

#include <chrono>
#include <cstddef>
#include <functional>
#include <optional>
#include <span>
#include <sstream>
#include <string>
#include <string_view>
#include <system_error>
#include <type_traits>
#include <utility>
#include <vector>

namespace logger {

    enum class LogLevel { Trace, Debug, Info, Warn, Error, Critical, Off };
    enum class LogOrigin { Framework, Application };
    enum class LogBoundary { Application, Configuration, Instance, Connection, Context, System };
    enum class LogRole { Unknown, Server, Client };
    enum class LogMessageFormat { None, Lenient, Strict };

    struct LogScope {
        LogOrigin origin;
        LogBoundary boundary;
        std::string_view component;
        std::string_view instance;
        LogRole role;
        std::string_view connection;
    };

    struct LogError {
        int code;
        std::string text;
    };

    struct LogSource {
        std::string file;
        int line;
        std::string func;
    };

    struct LogRecord {
        int v = 1;
        std::chrono::system_clock::time_point ts;
        LogLevel level;
        LogOrigin origin;
        LogBoundary boundary;
        std::string component;
        std::optional<std::string> instance;
        std::optional<LogRole> role;
        std::optional<std::string> connection;
        std::optional<std::string> event;
        std::string message;
        std::vector<std::string> messageArguments;
        LogMessageFormat messageFormat = LogMessageFormat::None;
        std::optional<std::string> hexDump;
        std::optional<std::string> terminalMessage;
        std::optional<LogError> error;
        std::optional<LogSource> source;
    };

    struct PresentedMessage {
        std::string plain;
        std::string terminal;
    };

    struct LogRecordOptions {
        std::optional<std::string_view> event;
        std::optional<LogError> error;
        std::optional<LogSource> source;
        std::chrono::system_clock::time_point ts = {};
    };

    LogRecord materialize(const LogScope& scope, LogLevel level, std::string message, LogRecordOptions options = {});

    std::string toString(LogLevel level);
    std::string toString(LogOrigin origin);
    std::string toString(LogBoundary boundary);
    std::optional<std::string_view> toString(LogRole role);
    std::string formatTimestamp(std::chrono::system_clock::time_point ts);
    std::string formatMessage(std::string_view pattern, const std::vector<std::string>& arguments, LogMessageFormat format);
    std::string formatJsonV1(const LogRecord& record);
    std::string formatText(const LogRecord& record);
    std::string formatText(const LogRecord& record, bool colorEnabled);

    class LogManager {
    public:
        enum class Format { Text, Json };

        LogManager() = delete;
        ~LogManager() = delete;

        static void init();
        static void setGlobalLevel(LogLevel level);
        static void setOriginLevel(LogOrigin origin, LogLevel level);
        static void setBoundaryLevel(LogBoundary boundary, LogLevel level);
        static void setComponentLevel(std::string component, LogLevel level);
        static void setInstanceLevel(std::string instance, LogLevel level);
        static void setFormat(Format format);
        static void freeze();
        static bool isFrozen();
        static unsigned long generation();

        static LogLevel effectiveLevel(const LogScope& scope);
        static LogLevel effectiveLevel(const LogRecord& record);
        static bool shouldEmit(const LogRecord& record);
        static Format format();
        static std::string formatRecord(const LogRecord& record);
    };

    class BoundaryLogger;

    struct OwnedLogScope {
        LogOrigin origin;
        LogBoundary boundary;
        std::string component;
        std::optional<std::string> instance;
        std::optional<LogRole> role;
        std::optional<std::string> connection;
    };

    bool knownLogRole(LogRole role) noexcept;
    OwnedLogScope copyLogScope(LogScope scope);
    LogScope viewLogScope(const OwnedLogScope& scope) noexcept;

    class LogScopeOwner;

    class LogStream {
    public:
        LogStream() = default;
        LogStream(const BoundaryLogger* logger, LogLevel level);
        LogStream(LogStream&& other) noexcept;
        LogStream& operator=(LogStream&& other) noexcept;
        LogStream(const LogStream&) = delete;
        LogStream& operator=(const LogStream&) = delete;
        ~LogStream();

        template <class T>
        LogStream& operator<<(const T& value) {
            if (enabled) {
                stream << value;
            }
            return *this;
        }

    private:
        const BoundaryLogger* logger = nullptr;
        LogLevel level = LogLevel::Off;
        bool enabled = false;
        bool flushed = true;
        std::ostringstream stream;
    };

    class BoundaryLogger {
    public:
        class Sink {
        public:
            Sink() = default;
            Sink(const Sink&) = default;
            Sink& operator=(const Sink&) = default;
            Sink(Sink&&) noexcept = default;
            Sink& operator=(Sink&&) noexcept = default;
            ~Sink() = default;

            template <class Callback, std::enable_if_t<!std::is_same_v<std::decay_t<Callback>, Sink>, int> = 0>
            Sink(Callback&& callback, bool acceptsDeferredRecords = false)
                : callback(std::forward<Callback>(callback))
                , deferredRecords(acceptsDeferredRecords) {
            }

            explicit operator bool() const noexcept {
                return static_cast<bool>(callback);
            }

            void operator()(LogRecord record) const {
                callback(std::move(record));
            }

            bool acceptsDeferredRecords() const noexcept {
                return deferredRecords;
            }

        private:
            std::function<void(LogRecord)> callback;
            bool deferredRecords = false;
        };

        using Clock = std::function<std::chrono::system_clock::time_point()>;

        static BoundaryLogger createForTest(LogScope scope, Sink sink, LogLevel threshold = LogLevel::Trace, Clock clock = {});

        bool enabled(LogLevel level) const noexcept;
        void hexDump(LogLevel level, std::string_view label, std::span<const std::byte> bytes) const;
        void hexDump(LogLevel level, std::string_view label, std::string_view bytes) const;

        LogStream trace() const;
        LogStream debug() const;
        LogStream info() const;
        LogStream warn() const;
        LogStream error() const;
        LogStream critical() const;

        template <class... Args>
        void trace(std::string_view format, Args&&... args) const {
            emitFormatted(LogLevel::Trace, format, std::forward<Args>(args)...);
        }
        template <class... Args>
        void debug(std::string_view format, Args&&... args) const {
            emitFormatted(LogLevel::Debug, format, std::forward<Args>(args)...);
        }
        template <class... Args>
        void info(std::string_view format, Args&&... args) const {
            emitFormatted(LogLevel::Info, format, std::forward<Args>(args)...);
        }
        template <class... Args>
        void warn(std::string_view format, Args&&... args) const {
            emitFormatted(LogLevel::Warn, format, std::forward<Args>(args)...);
        }
        template <class... Args>
        void error(std::string_view format, Args&&... args) const {
            emitFormatted(LogLevel::Error, format, std::forward<Args>(args)...);
        }
        template <class... Args>
        void critical(std::string_view format, Args&&... args) const {
            emitFormatted(LogLevel::Critical, format, std::forward<Args>(args)...);
        }

        template <class... Args>
        void sysError(LogLevel level, int errnum, std::string_view format, Args&&... args) const {
            if (!enabled(level)) {
                return;
            }

            LogRecordOptions options;
            options.error = LogError{errnum, std::error_code(errnum, std::generic_category()).message()};
            emitDeferred(
                level, std::string(format), collectArgs(std::forward<Args>(args)...), LogMessageFormat::Lenient, std::move(options));
        }

        template <class... Args>
        void sysError(LogLevel level, std::error_code errorCode, std::string_view format, Args&&... args) const {
            if (!enabled(level)) {
                return;
            }

            LogRecordOptions options;
            options.error = LogError{errorCode.value(), errorCode.message()};
            emitDeferred(
                level, std::string(format), collectArgs(std::forward<Args>(args)...), LogMessageFormat::Lenient, std::move(options));
        }

        void emit(LogLevel level, std::string message, LogRecordOptions options = {}) const;
        void emit(LogLevel level, PresentedMessage message, LogRecordOptions options = {}) const;
        void emitDeferred(LogLevel level,
                          std::string format,
                          std::vector<std::string> arguments,
                          LogMessageFormat messageFormat,
                          LogRecordOptions options = {}) const;

    private:
        BoundaryLogger(OwnedLogScope scope, Sink sink, LogLevel threshold, Clock clock);

        template <class... Args>
        void emitFormatted(LogLevel level, std::string_view format, Args&&... args) const {
            if (!enabled(level)) {
                return;
            }

            emitDeferred(level, std::string(format), collectArgs(std::forward<Args>(args)...), LogMessageFormat::Lenient);
        }

        template <class T>
        static std::string stringify(T&& value) {
            std::ostringstream out;
            out << std::forward<T>(value);
            return out.str();
        }
        template <class... Args>
        static std::vector<std::string> collectArgs(Args&&... args) {
            std::vector<std::string> values;
            values.reserve(sizeof...(Args));
            (values.emplace_back(stringify(std::forward<Args>(args))), ...);
            return values;
        }

        OwnedLogScope scope;
        Sink sink;
        LogLevel threshold;
        Clock clock;

        friend class LogStream;
        friend class LogScopeOwner;
    };

} // namespace logger

#endif // LOGGER_SEMANTICLOGGER_H
