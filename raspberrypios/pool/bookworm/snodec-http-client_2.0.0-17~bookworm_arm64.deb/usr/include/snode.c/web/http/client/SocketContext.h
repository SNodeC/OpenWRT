/*
 * SNode.C - A Slim Toolkit for Network Communication
 * Copyright (C) Volker Christian <me@vchrist.at>
 *               2020, 2021, 2022, 2023, 2024, 2025, 2026
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * MIT License
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

#ifndef WEB_HTTP_CLIENT_SOCKETCONTEXT_H
#define WEB_HTTP_CLIENT_SOCKETCONTEXT_H

#include "core/socket/stream/SocketContext.h" // IWYU pragma: export
#include "web/http/client/ResponseParser.h"   // IWYU pragma: export

namespace web::http {
    struct ParserLimits;
}

namespace core::socket::stream {
    class SocketConnection;
}

namespace web::http::client {
    class MasterRequest;
}

#ifndef DOXYGEN_SHOULD_SKIP_THIS

#include <cstddef>
#include <functional>
#include <list>
#include <memory> // IWYU pragma: export
#include <set>
#include <string>

#endif /* DOXYGEN_SHOULD_SKIP_THIS */

namespace web::http::client {

    class SocketContext : public core::socket::stream::SocketContext {
    private:
        using Super = core::socket::stream::SocketContext;
        using Response = web::http::client::Response;

    public:
        SocketContext(core::socket::stream::SocketConnection* socketConnection,
                      const std::function<void(const std::shared_ptr<MasterRequest>&)>& onHttpConnected,
                      const std::function<void(const std::shared_ptr<MasterRequest>&)>& onHttpDisconnected,
                      const std::string& hostHeader,
                      bool pipelinedRequests,
                      const web::http::ParserLimits& parserLimits = {});

        ~SocketContext() override;

    private:
        void requestPrepared(const std::shared_ptr<MasterRequest>& request);
        void initiateRequest();
        void requestDelivered(bool success);
        void responseStarted();
        void deliverResponse(const std::shared_ptr<Response>& response);
        void deliverResponseParseError(int status, const std::string& reason);
        void requestCompleted(const std::shared_ptr<Response>& response);
        void requestTerminal(const std::shared_ptr<MasterRequest>& request, const char* outcome);

        void setSseEventReceiver(const std::function<std::size_t()>& onServerSentEvent);

        std::function<void(const std::shared_ptr<MasterRequest>&)> onHttpConnected;
        std::function<void(const std::shared_ptr<MasterRequest>&)> onHttpDisconnected;

        void onConnected() override;
        std::size_t onReceivedFromPeer() override;
        void onDisconnected() override;
        bool onSignal(int signum) override;
        void onWriteError(int errnum) override;

        std::function<std::size_t()> onServerSentEvent = nullptr;

        std::list<std::shared_ptr<MasterRequest>> pendingRequests;
        std::list<std::shared_ptr<MasterRequest>> deliveredRequests;
        std::set<std::size_t> startedRequests;

        bool pipelinedRequests = false;

        std::shared_ptr<MasterRequest> masterRequest;

        ResponseParser parser;

        enum Flags { //
            NONE = 0b00000000,
            HTTP10 = 0b00000001,
            HTTP11 = 0b00000010,
            KEEPALIVE = 0b00000100,
            CLOSE = 0b00001000
        };
        int flags = Flags::NONE;

        bool httpClose = false;

        friend class web::http::client::MasterRequest;
    };

} // namespace web::http::client

#endif // WEB_HTTP_CLIENT_SOCKETCONTEXT_H
