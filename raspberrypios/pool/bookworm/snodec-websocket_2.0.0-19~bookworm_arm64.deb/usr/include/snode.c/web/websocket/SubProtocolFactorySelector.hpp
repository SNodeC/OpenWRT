/*
 * SNode.C - A Slim Toolkit for Network Communication
 * Copyright (C) Volker Christian <me@vchrist.at>
 *               2020, 2021, 2022, 2023, 2024, 2025, 2026
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * MIT License
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

#include "web/websocket/SemanticLog.h"
#include "web/websocket/SubProtocolFactorySelector.h"

#ifndef DOXYGEN_SHOULD_SKIP_THIS

#include "log/SemanticLogger.h"

#include <filesystem>
#include <list>

#endif /* DOXYGEN_SHOULD_SKIP_THIS */

namespace web::websocket {

    template <typename SubProtocolFactory>
    SubProtocolFactory* SubProtocolFactorySelector<SubProtocolFactory>::load(const std::string& subProtocolName,
                                                                             const std::string& subProtocolLibraryFile,
                                                                             const std::string& subProtocolFactoryFunctionName) {
        SubProtocolFactory* subProtocolFactory = nullptr;

        void* handle = core::DynamicLoader::dlOpen(subProtocolLibraryFile);

        if (handle != nullptr) {
            SubProtocolFactory* (*getSubProtocolFactory)() =
                reinterpret_cast<SubProtocolFactory* (*) ()>(core::DynamicLoader::dlSym(handle, subProtocolFactoryFunctionName));
            if (getSubProtocolFactory != nullptr) {
                subProtocolFactory = getSubProtocolFactory();
                if (subProtocolFactory != nullptr) {
                    subProtocolFactory->setHandle(handle);
                    semantic::webSocketFactoryLog().debug() << "SubProtocolFactory create success: " << subProtocolName;
                } else {
                    semantic::webSocketFactoryLog().debug() << "SubProtocolFactory create failed: " << subProtocolName;
                    core::DynamicLoader::dlClose(handle);
                }
            } else {
                semantic::webSocketFactoryLog().debug() << "Optaining function \"" << subProtocolFactoryFunctionName
                                                        << "\" in plugin failed: " << core::DynamicLoader::dlError();
                core::DynamicLoader::dlClose(handle);
            }
        }

        return subProtocolFactory;
    }

    template <typename SubProtocolFactory>
    SubProtocolFactory* SubProtocolFactorySelector<SubProtocolFactory>::select(const std::string& subProtocolName,
                                                                               [[maybe_unused]] Role role) {
        SubProtocolFactory* subProtocolFactory = nullptr;

        if (subProtocolFactories.contains(subProtocolName)) {
            subProtocolFactory = subProtocolFactories[subProtocolName];

            semantic::webSocketFactoryLog().debug() << "subprotocol plugin '" << subProtocolName << "' selected from dynamic cache";
        } else if (linkedSubProtocolFactories.contains(subProtocolName)) {
            SubProtocolFactory* (*plugin)() = linkedSubProtocolFactories[subProtocolName];
            subProtocolFactory = plugin();

            semantic::webSocketFactoryLog().debug() << "subprotocol plugin '" << subProtocolName << "' selected from static cache";
        } else if (!onlyLinked) {
            subProtocolFactory = load(subProtocolName);
            subProtocolFactories.insert({subProtocolName, subProtocolFactory});

            semantic::webSocketFactoryLog().debug() << "subprotocol plugin '" << subProtocolName << "' loaded and added to dynamic cache";
        } else {
            semantic::webSocketFactoryLog().warn() << "subprotocol plugin '" << subProtocolName << "' not found";
        }

        return subProtocolFactory;
    }

    template <typename SubProtocolFactory>
    void SubProtocolFactorySelector<SubProtocolFactory>::allowDlOpen() {
        onlyLinked = false;
    }

} // namespace web::websocket
