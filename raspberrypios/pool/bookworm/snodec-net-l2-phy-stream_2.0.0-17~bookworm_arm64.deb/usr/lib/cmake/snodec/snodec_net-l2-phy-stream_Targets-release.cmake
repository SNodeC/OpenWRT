#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "snodec::net-l2-phy-stream" for configuration "Release"
set_property(TARGET snodec::net-l2-phy-stream APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(snodec::net-l2-phy-stream PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libsnodec-net-l2-phy-stream.so.2.0.0"
  IMPORTED_SONAME_RELEASE "libsnodec-net-l2-phy-stream.so.2"
  )

list(APPEND _cmake_import_check_targets snodec::net-l2-phy-stream )
list(APPEND _cmake_import_check_files_for_snodec::net-l2-phy-stream "${_IMPORT_PREFIX}/lib/libsnodec-net-l2-phy-stream.so.2.0.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
