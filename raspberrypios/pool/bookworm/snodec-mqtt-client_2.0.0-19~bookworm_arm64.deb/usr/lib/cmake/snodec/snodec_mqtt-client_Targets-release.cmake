#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "snodec::mqtt-client" for configuration "Release"
set_property(TARGET snodec::mqtt-client APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(snodec::mqtt-client PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/snode.c/iot/mqtt/libsnodec-mqtt-client.so.2.0.0"
  IMPORTED_SONAME_RELEASE "libsnodec-mqtt-client.so.2"
  )

list(APPEND _cmake_import_check_targets snodec::mqtt-client )
list(APPEND _cmake_import_check_files_for_snodec::mqtt-client "${_IMPORT_PREFIX}/lib/snode.c/iot/mqtt/libsnodec-mqtt-client.so.2.0.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
