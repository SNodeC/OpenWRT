#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "snodec::net-un-stream-tls" for configuration "Release"
set_property(TARGET snodec::net-un-stream-tls APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(snodec::net-un-stream-tls PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libsnodec-net-un-stream-tls.so.2.0.0"
  IMPORTED_SONAME_RELEASE "libsnodec-net-un-stream-tls.so.2"
  )

list(APPEND _cmake_import_check_targets snodec::net-un-stream-tls )
list(APPEND _cmake_import_check_files_for_snodec::net-un-stream-tls "${_IMPORT_PREFIX}/lib/libsnodec-net-un-stream-tls.so.2.0.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
