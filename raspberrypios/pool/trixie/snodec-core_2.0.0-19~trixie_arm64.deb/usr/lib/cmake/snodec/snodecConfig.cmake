# SNode.C - A Slim Toolkit for Network Communication
# Copyright (C) Volker Christian <me@vchrist.at>
#               2020, 2021, 2022, 2023, 2024, 2025, 2026
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published
# by the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#
# ---------------------------------------------------------------------------
#
# MIT License
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
#
# ########################################################################### #

set(utils_DEPENDENCIES logger)
set(core-socket-stream-legacy_DEPENDENCIES core-socket-stream)
set(core-socket-stream-tls_DEPENDENCIES core-socket-stream)
set(core-socket-stream_DEPENDENCIES core-socket)
set(core-socket_DEPENDENCIES core)
set(core_DEPENDENCIES mux-epoll;utils)
set(net-in-phy-stream_DEPENDENCIES net-in-phy)
set(net-in-phy_DEPENDENCIES net-in)
set(net-in-stream-legacy_DEPENDENCIES net-in-stream;core-socket-stream-legacy)
set(net-in-stream-tls_DEPENDENCIES net-in-stream;core-socket-stream-tls)
set(net-in-stream_DEPENDENCIES net-in-phy-stream)
set(net-in_DEPENDENCIES net)
set(net-in6-phy-stream_DEPENDENCIES net-in6-phy)
set(net-in6-phy_DEPENDENCIES net-in6)
set(net-in6-stream-legacy_DEPENDENCIES net-in6-stream;core-socket-stream-legacy)
set(net-in6-stream-tls_DEPENDENCIES net-in6-stream;core-socket-stream-tls)
set(net-in6-stream_DEPENDENCIES net-in6-phy-stream)
set(net-in6_DEPENDENCIES net)
set(net-l2-phy-stream_DEPENDENCIES net-l2-phy)
set(net-l2-phy_DEPENDENCIES net-l2)
set(net-l2-stream-legacy_DEPENDENCIES net-l2-stream;core-socket-stream-legacy)
set(net-l2-stream-tls_DEPENDENCIES net-l2-stream;core-socket-stream-tls)
set(net-l2-stream_DEPENDENCIES net-l2-phy-stream)
set(net-l2_DEPENDENCIES net)
set(net-rc-phy-stream_DEPENDENCIES net-rc-phy)
set(net-rc-phy_DEPENDENCIES net-rc)
set(net-rc-stream-legacy_DEPENDENCIES net-rc-stream;core-socket-stream-legacy)
set(net-rc-stream-tls_DEPENDENCIES net-rc-stream;core-socket-stream-tls)
set(net-rc-stream_DEPENDENCIES net-rc-phy-stream)
set(net-rc_DEPENDENCIES net)
set(net-un-phy-stream_DEPENDENCIES net-un-phy)
set(net-un-phy_DEPENDENCIES net-un)
set(net-un-stream-legacy_DEPENDENCIES net-un-stream;core-socket-stream-legacy)
set(net-un-stream-tls_DEPENDENCIES net-un-stream;core-socket-stream-tls)
set(net-un-stream_DEPENDENCIES net-un-phy-stream)
set(net-un-dgram_DEPENDENCIES net-un-phy;net-un)
set(net-un_DEPENDENCIES net)
set(net_DEPENDENCIES core-socket)
set(http-server_DEPENDENCIES http)
set(http-client_DEPENDENCIES http)
set(http_DEPENDENCIES core-socket-stream)
set(websocket-server_DEPENDENCIES websocket;http-server)
set(websocket-client_DEPENDENCIES websocket;http-client)
set(websocket_DEPENDENCIES utils)
set(http-server-express-legacy-in_DEPENDENCIES net-in-stream-legacy;http-server-express)
set(http-server-express-legacy-in6_DEPENDENCIES net-in6-stream-legacy;http-server-express)
set(http-server-express-legacy-rc_DEPENDENCIES net-rc-stream-legacy;http-server-express)
set(http-server-express-legacy-un_DEPENDENCIES net-un-stream-legacy;http-server-express)
set(http-server-express-tls-in_DEPENDENCIES http-server;net-in-stream-tls;http-server-express)
set(http-server-express-tls-in6_DEPENDENCIES http-server;net-in6-stream-tls;http-server-express)
set(http-server-express-tls-rc_DEPENDENCIES http-server;net-rc-stream-tls;http-server-express)
set(http-server-express-tls-un_DEPENDENCIES http-server;net-un-stream-tls;http-server-express)
set(http-server-express_DEPENDENCIES http-server)
set(db-mariadb_DEPENDENCIES core)
set(mqtt-server_DEPENDENCIES mqtt)
set(mqtt-server-websocket_DEPENDENCIES mqtt-server;websocket-server)
set(mqtt-client_DEPENDENCIES mqtt)
set(mqtt-client-websocket_DEPENDENCIES mqtt-client;websocket-client)
set(mqtt_DEPENDENCIES core-socket-stream)


####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was Config.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

# Use original install prefix when loaded through a "/usr move"
# cross-prefix symbolic link such as /lib -> /usr/lib.
get_filename_component(_realCurr "${CMAKE_CURRENT_LIST_DIR}" REALPATH)
get_filename_component(_realOrig "/usr/lib/cmake/snodec" REALPATH)
if(_realCurr STREQUAL _realOrig)
  set(PACKAGE_PREFIX_DIR "/usr")
endif()
unset(_realOrig)
unset(_realCurr)

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

macro(load_component_with_dependencies _comp _lspace _ladd)
    if(NOT ${_comp}_LOADED)
        if(${_comp}_DEPENDENCIES)
            list(JOIN ${_comp}_DEPENDENCIES ", " CURRENT_COMP_DEPENDENCIES)
            message("${_lspace}${_comp}: loading dependencies "
                    "\'${CURRENT_COMP_DEPENDENCIES}\'"
            )
            foreach(_depcomp ${${_comp}_DEPENDENCIES})
                load_component_with_dependencies(
                    ${_depcomp} "${_lspace}${_ladd}" "${_ladd}"
                )
            endforeach(_depcomp ${${_comp}_DEPENDENCIES})
        endif(${_comp}_DEPENDENCIES)
        include("${CMAKE_CURRENT_LIST_DIR}/snodec_${_comp}_Targets.cmake")
        include("${CMAKE_CURRENT_LIST_DIR}/snodec_${_comp}_Targets_Config.cmake"
                OPTIONAL RESULT_VARIABLE ${_comp}_TARGETS_CONFIG_FILE
        )
        message("${_lspace}${_comp}: loaded")
        if(NOT "${${_comp}_TARGETS_CONFIG_FILE}" STREQUAL "NOTFOUND")
            message("${_lspace}${_comp}: configured")
        endif(NOT "${${_comp}_TARGETS_CONFIG_FILE}" STREQUAL "NOTFOUND")
        set(${_comp}_LOADED true)
    else(NOT ${_comp}_LOADED)
        message("${_lspace}${_comp}: already loaded")
    endif(NOT ${_comp}_LOADED)
endmacro()

set(_supported_components core
    core-socket-stream-legacy
    core-socket-stream-tls
    net
    net-in-stream-legacy
    net-in6-stream-legacy
    net-un-stream-legacy
    net-in-stream-tls
    net-in6-stream-tls
    net-un-stream-tls
    net-rc-stream-legacy
    net-rc-stream-tls
    net-l2-stream-legacy
    net-l2-stream-tls
    net-un-dgram
    db-mariadb
    http
    http-server
    http-client
    http-server-express
    http-server-express-legacy-in
    http-server-express-legacy-in6
    http-server-express-legacy-rc
    http-server-express-legacy-un
    http-server-express-tls-in
    http-server-express-tls-in6
    http-server-express-tls-rc
    http-server-express-tls-un
    websocket-server
    websocket-client
    mqtt
    mqtt-server
    mqtt-client
    mqtt-server-websocket
    mqtt-client-websocket)
set(snodec_FOUND TRUE)

foreach(_comp ${snodec_FIND_COMPONENTS})
    if(NOT _comp IN_LIST _supported_components)
        set(snodec_FOUND FALSE)
        set(snodec_NOT_FOUND_MESSAGE
            "Unsupported SNode.C component requested: ${_comp}"
        )
        break()
    else(NOT _comp IN_LIST _supported_components)
        load_component_with_dependencies(${_comp} "" "  ")
        check_required_components(${_comp})
    endif(NOT _comp IN_LIST _supported_components)
endforeach(_comp ${snodec_FIND_COMPONENTS})

if(snodec_FOUND)
    set(CMAKE_SKIP_RPATH FALSE)
    set(CMAKE_INSTALL_RPATH_USE_LINK_PATH TRUE)
    list(FIND CMAKE_PLATFORM_IMPLICIT_LINK_DIRECTORIES
         "${CMAKE_INSTALL_PREFIX}/${CMAKE_INSTALL_LIBDIR}" isSystemDir
    )
    if("${isSystemDir}" STREQUAL "-1")
        set(CMAKE_INSTALL_RPATH
            "${CMAKE_INSTALL_PREFIX}/${CMAKE_INSTALL_LIBDIR}"
        )
    endif("${isSystemDir}" STREQUAL "-1")
    set(SNODEC_SOVERSION 2)
    add_link_options(LINKER:--as-needed)
endif()
