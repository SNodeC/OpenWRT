#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "snodec::core" for configuration "Release"
set_property(TARGET snodec::core APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(snodec::core PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "snodec::mux-epoll"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libsnodec-core.so.2.0.0"
  IMPORTED_SONAME_RELEASE "libsnodec-core.so.2"
  )

list(APPEND _cmake_import_check_targets snodec::core )
list(APPEND _cmake_import_check_files_for_snodec::core "${_IMPORT_PREFIX}/lib/libsnodec-core.so.2.0.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
