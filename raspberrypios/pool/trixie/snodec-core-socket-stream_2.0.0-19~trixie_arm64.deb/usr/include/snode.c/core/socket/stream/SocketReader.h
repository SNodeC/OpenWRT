/*
 * SNode.C - A Slim Toolkit for Network Communication
 * Copyright (C) Volker Christian <me@vchrist.at>
 *               2020, 2021, 2022, 2023, 2024, 2025, 2026
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * MIT License
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

#ifndef CORE_SOCKET_STREAM_SOCKETREADER_H
#define CORE_SOCKET_STREAM_SOCKETREADER_H

#include "core/eventreceiver/ReadEventReceiver.h"

namespace logger {
    struct LogScope;
}

#ifndef DOXYGEN_SHOULD_SKIP_THIS

#include "utils/Timeval.h"

#include <cstddef>
#include <functional>
#include <string>
#include <sys/types.h>
#include <vector>

#endif /* DOXYGEN_SHOULD_SKIP_THIS */

namespace core::socket::stream {
    namespace tls::detail {
        struct TLSLifecycleTestAccess;
    }

    class SocketReader : public core::eventreceiver::ReadEventReceiver {
    public:
        SocketReader() = delete;

    protected:
        explicit SocketReader(const std::string& name,
                              logger::LogScope logScope,
                              const std::function<void(int)>& onStatus,
                              const utils::Timeval& timeout,
                              std::size_t blockSize,
                              const utils::Timeval& terminateTimeout);

        std::size_t getTotalRead() const;
        std::size_t getTotalProcessed() const;

    private:
        virtual void onReceivedFromPeer(std::size_t available) = 0;

        void readEvent() final;

        std::size_t doRead();
        void signalEvent(int sigNum) final;

    protected:
        virtual ssize_t read(char* chunk, std::size_t chunkLen);

        void setBlockSize(std::size_t readBlockSize);

        std::size_t readFromPeer(char* chunk, std::size_t chunkLen);

        void shutdownRead();

    private:
        std::function<void(int)> onStatus;

        std::vector<char> readBuffer;
        std::size_t blockSize = 0;

        std::size_t totalRead = 0;
        std::size_t totalProcessed = 0;

        std::size_t size = 0;
        std::size_t cursor = 0;

        bool shutdownInProgress = false;

    protected:
        utils::Timeval terminateTimeout;

        friend struct tls::detail::TLSLifecycleTestAccess;
    };

} // namespace core::socket::stream

#endif // CORE_SOCKET_STREAM_SOCKETREADER_H
