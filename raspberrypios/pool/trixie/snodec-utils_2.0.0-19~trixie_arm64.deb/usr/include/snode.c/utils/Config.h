/*
 * SNode.C - A Slim Toolkit for Network Communication
 * Copyright (C) Volker Christian <me@vchrist.at>
 *               2020, 2021, 2022, 2023, 2024, 2025, 2026
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * MIT License
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

#ifndef UTILS_CONFIG_H
#define UTILS_CONFIG_H

#include "log/SemanticLogger.h"
#include "utils/SubCommand.h"

#ifndef DOXYGEN_SHOULD_SKIP_THIS

#include <cstddef>
#include <string>
#include <string_view>
#include <utility> // IWYU pragma: keep
#include <vector>  // IWYU pragma: keep

// IWYU pragma: no_include <format>
// IWYU pragma: no_include <iterator>

#endif /* DOXYGEN_SHOULD_SKIP_THIS */

namespace utils::config {

    struct ParsedLogLevel {
        int legacyLevel;
        logger::LogLevel semanticLevel;
    };

    ParsedLogLevel parseLogLevel(std::string_view value);
    logger::LogManager::Format parseLogFormat(std::string_view value);
    logger::LogOrigin parseLogOrigin(std::string_view value);
    logger::LogBoundary parseLogBoundary(std::string_view value);
    std::pair<std::string, logger::LogLevel> parseKeyValueLevel(std::string_view value);
    std::vector<std::pair<std::string, logger::LogLevel>> parseKeyValueLevelList(std::string_view value);

} // namespace utils::config

namespace utils {

    class ConfigRoot : public utils::SubCommand {
    private:
        ConfigRoot();

    public:
        void* operator new(std::size_t) = delete;

        ~ConfigRoot() override;

    private:
        ConfigRoot* addRootOptions(const std::string& applicationName,
                                   const std::string& userName,
                                   const std::string& groupName,
                                   const std::string& configDirectory,
                                   const std::string& logDirectory,
                                   const std::string& pidDirectory);
        enum class ParsePhase { Initial, Bootstrap, Runtime };
        bool parse1(int argc, char* argv[]);
        bool parse2(int argc, char* argv[], ParsePhase phase);
        void terminate();

        std::string applicationName;
        std::string pidDirectory;

        CLI::Option* daemonizeOpt = nullptr;
        CLI::Option* logFileOpt = nullptr;
        CLI::Option* monochromLogOpt = nullptr;
        CLI::Option* userNameOpt = nullptr;
        CLI::Option* groupNameOpt = nullptr;
        CLI::Option* enforceLogFileOpt = nullptr;
        CLI::Option* logLevelOpt = nullptr;
        CLI::Option* verboseLevelOpt = nullptr;
        CLI::Option* logFormatOpt = nullptr;
        CLI::Option* logOriginLevelOpt = nullptr;
        CLI::Option* logBoundaryLevelOpt = nullptr;
        CLI::Option* logComponentLevelOpt = nullptr;
        CLI::Option* logInstanceLevelOpt = nullptr;
        CLI::Option* quietOpt = nullptr;
        CLI::Option* versionOpt = nullptr;
        CLI::Option* writeConfigOpt = nullptr;
        CLI::Option* killOpt = nullptr;
        CLI::Option* aliasOpt = nullptr;

        friend class Config;
    };

    class Config {
    public:
        Config() = delete;
        Config(const Config&) = delete;
        ~Config() = delete;

        Config& operator=(const Config&) = delete;

        static bool init(int argc, char* argv[]);
        static bool bootstrap();
        [[nodiscard]] static bool reconfigure();
        // Legacy unchecked parsing; application lifecycle callers should use SNodeC::reconfigure().
        static void parse();
        static void terminate();

        static const std::string& getApplicationName();
        static int getLogLevel();
        static int getVerboseLevel();

        static ConfigRoot configRoot;

    private:
        static int argc;
        static char** argv;

        static std::string applicationName;

        static std::string configDirectory;
        static std::string logDirectory;
        static std::string pidDirectory;

        friend class ConfigRoot;
    };

} // namespace utils

#endif // UTILS_CONFIG_H
