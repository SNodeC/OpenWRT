/*
 * SNode.C - A Slim Toolkit for Network Communication
 * Copyright (C) Volker Christian <me@vchrist.at>
 *               2020, 2021, 2022, 2023, 2024, 2025, 2026
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * MIT License
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

#ifndef UTILS_SUBCOMMAND_H
#define UTILS_SUBCOMMAND_H

#ifndef DOXYGEN_SHOULD_SKIP_THIS

#include <cstddef>
#include <functional>
#include <map>
#include <memory>
#include <set>
#include <string>
#include <utility>

#ifdef __GNUC__
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wfloat-equal"
#ifdef __has_warning
#if __has_warning("-Wweak-vtables")
#pragma GCC diagnostic ignored "-Wweak-vtables"
#endif
#if __has_warning("-Wcovered-switch-default")
#pragma GCC diagnostic ignored "-Wcovered-switch-default"
#endif
#if __has_warning("-Wmissing-noreturn")
#pragma GCC diagnostic ignored "-Wmissing-noreturn"
#endif
#if __has_warning("-Wnrvo")
#pragma GCC diagnostic ignored "-Wnrvo"
#endif
#endif
#endif
#include "utils/CLI11.hpp" // IWYU pragma: export
#ifdef __GNUC__
#pragma GCC diagnostic pop
#endif

#endif // DOXYGEN_SHOULD_SKIP_THIS

namespace utils {
    class SubCommand;

    enum class ConfigSuppressionReason {
        Disabled,
        ForceUnrequired
    };

    struct ConfigRequirementState {
        bool canonicalRequired = false;
        bool effectiveRequiredBase = false;
        bool effectiveRequired = false;
        std::set<ConfigSuppressionReason> suppressions;
    };

    struct ConfigOptionState {
        ConfigRequirementState required;
    };

    struct ConfigNodeState {
        ConfigRequirementState required;
        std::set<const CLI::Option*> canonicalOptionNeeds;
        std::set<const CLI::Option*> effectiveOptionNeeds;
        std::set<const CLI::App*> canonicalNeeds;
        std::set<const CLI::App*> effectiveNeeds;
    };

    class AppWithPtr : public CLI::App {
    public:
        AppWithPtr(const std::string& description, const std::string& name, SubCommand* t);

        ~AppWithPtr() override;

        const SubCommand* getPtr() const;
        SubCommand* getPtr();

        CLI11_INLINE CLI::Option*
        set_help_flag(std::string flag_name, std::function<void(std::size_t)> help_callback, const std::string& help_description);

        void setCanonicalRequired(bool required);
        void setEffectiveRequiredBase(bool required);
        void setCanonicalRequired(CLI::Option* option, bool required);
        void setSuppression(ConfigSuppressionReason reason, bool suppressed);
        void setSuppression(CLI::Option* option, ConfigSuppressionReason reason, bool suppressed);
        void setSuppressionRecursive(ConfigSuppressionReason reason, bool suppressed);

        void setCanonicalNeed(CLI::Option* option, bool needed);
        void setCanonicalNeed(CLI::App* app, bool needed);

        bool canonicalRequired() const;
        bool effectiveRequired() const;
        bool canonicalRequired(const CLI::Option* option) const;
        bool effectiveRequired(const CLI::Option* option) const;
        bool hasSuppression(ConfigSuppressionReason reason) const;
        bool hasSuppression(const CLI::Option* option, ConfigSuppressionReason reason) const;
        bool canonicalNeeds(const CLI::Option* option) const;
        bool effectiveNeeds(const CLI::Option* option) const;
        bool canonicalNeeds(const CLI::App* app) const;
        bool effectiveNeeds(const CLI::App* app) const;

    private:
        ConfigOptionState& optionState(const CLI::Option* option);
        const ConfigOptionState* findOptionState(const CLI::Option* option) const;
        void applyEffectiveState();

        SubCommand* ptr;
        ConfigNodeState configState;
        std::map<const CLI::Option*, ConfigOptionState> optionConfigStates;
    };

    class SubCommand {
    protected:
        SubCommand(SubCommand* parent, std::shared_ptr<utils::AppWithPtr> appWithPtr, const std::string& group, bool final = false);

        template <typename ConcretSubCommand>
        SubCommand(SubCommand* parent, ConcretSubCommand* concretSubCommand, const std::string& group, bool final = false);

    public:
        SubCommand(const SubCommand&) = delete;
        SubCommand(SubCommand&&) = delete;

        SubCommand& operator=(const SubCommand&) = delete;
        SubCommand& operator=(SubCommand&&) = delete;

        virtual ~SubCommand();

        std::string getName() const;
        std::string version() const;

    protected:
        void parse(int argc, char* argv[]) const;

        SubCommand* description(const std::string& description);
        SubCommand* footer(const std::string& footer);

        void removeSubCommand();

    public:
        std::string configToStr() const;
        std::string help(const CLI::App* helpApp, const CLI::AppFormatMode& mode) const;

        bool hasParent() const;
        SubCommand* getParent() const;
        const AppWithPtr* getAppWithPtr() const;
        AppWithPtr* getAppWithPtr();

        SubCommand* allowExtras(bool allow = true);

        SubCommand* forceUnrequired(bool unrequired = true);
        SubCommand* required(bool required = true);
        SubCommand* required(CLI::Option* option, bool required = true);

        bool getRequired() const;

        SubCommand* needs(SubCommand* subCommand, bool needs = true);

        SubCommand* setRequireCallback(const std::function<void(void)>& callback);
        SubCommand* finalCallback(const std::function<void()>& finalCallback);

        void addSubCommandApp(std::shared_ptr<utils::AppWithPtr> subCommand);

        template <typename NewSubCommand, typename... Args>
        NewSubCommand* newSubCommand(Args&&... args);

        template <typename RequestedSubCommand>
        RequestedSubCommand* getSubCommand();

        template <typename RequestedSubCommand>
        RequestedSubCommand* getSubCommand() const;

    protected:
        SubCommand* suppressRequirements(ConfigSuppressionReason reason, bool suppressed);

        CLI::Option* addConfigFlag(const std::string& defaultConfigFile) const;
        CLI::Option* addLogFileFlag(const std::string& defaultLogFile) const;
        CLI::Option* addVersionFlag(const std::string& version) const;

    public:
        CLI::Option* addOption(const std::string& name,
                               const std::string& description,
                               const std::string& typeName,
                               const CLI::Validator& validator) const;

        template <typename ValueTypeT>
        CLI::Option* addOption(const std::string& name,
                               const std::string& description,
                               const std::string& typeName,
                               ValueTypeT defaultValue,
                               const CLI::Validator& validator) const;

        template <typename ValueTypeT>
        CLI::Option* addOptionVariable(const std::string& name,
                                       ValueTypeT& variable,
                                       const std::string& description,
                                       const std::string& typeName,
                                       const CLI::Validator& additionalValidator) const;

        template <typename ValueTypeT>
        CLI::Option* addOptionVariable(const std::string& name,
                                       ValueTypeT& variable,
                                       const std::string& description,
                                       const std::string& typeName,
                                       ValueTypeT defaultValue,
                                       const CLI::Validator& additionalValidator) const;

        CLI::Option* addOptionFunction(const std::string& name,
                                       const std::function<void(const std::string&)>& callback,
                                       const std::string& description,
                                       const std::string& typeName,
                                       const CLI::Validator& validator) const;

        template <typename ValueTypeT>
        CLI::Option* addOptionFunction(const std::string& name,
                                       const std::function<void(const std::string&)>& callback,
                                       const std::string& description,
                                       const std::string& typeName,
                                       ValueTypeT defaultValue,
                                       const CLI::Validator& validator) const;

        CLI::Option* addFlag(const std::string& name,
                             const std::string& description,
                             const std::string& typeName,
                             const CLI::Validator& validator) const;

        template <typename ValueTypeT>
        CLI::Option* addFlag(const std::string& name,
                             const std::string& description,
                             const std::string& typeName,
                             ValueTypeT defaultValue,
                             const CLI::Validator& validator) const;

        CLI::Option* addFlagFunction(const std::string& name,
                                     const std::function<void()>& callback,
                                     const std::string& description,
                                     const std::string& typeName,
                                     const CLI::Validator& validator) const;

        CLI::Option* addFlagFunction(const std::string& name,
                                     const std::function<void()>& callback,
                                     const std::string& description,
                                     const std::string& typeName,
                                     const std::string& defaultValue,
                                     const CLI::Validator& validator) const;

        CLI::Option* getOption(const std::string& name) const;

        template <typename ValueTypeT>
        CLI::Option* setDefaultValue(CLI::Option* option, const ValueTypeT& value, bool clear = true) const;

        CLI::Option* setConfigurable(CLI::Option* option, bool configurable) const;

    protected:
        static CLI::App* getHelpTriggerApp();
        static CLI::App* getShowConfigTriggerApp();
        static CLI::App* getCommandlineTriggerApp();

        static std::map<std::string, std::string> aliases;

        static CLI::App* helpTriggerApp;
        static CLI::App* showConfigTriggerApp;
        static CLI::App* commandlineTriggerApp;

    private:
        void applyCanonicalRequiredContribution(bool previousCanonicalRequired, bool canonicalRequired);
        void applyEffectiveRequiredContribution(bool previousEffectiveRequired, bool effectiveRequired);

        CLI::Option* initialize(CLI::Option* option, const std::string& typeName, const CLI::Validator& validator, bool configurable) const;

        AppWithPtr* subCommandApp;
        std::string name;
        SubCommand* parent;

    protected:
        CLI::Option* helpOpt = nullptr;
        CLI::Option* showConfigOpt = nullptr;
        CLI::Option* commandlineOpt = nullptr;

    private:
        std::shared_ptr<AppWithPtr> selfAnchoredSubCommandApp;
        // Owns only SubCommand objects allocated by newSubCommand().
        // ConfigSection base subobjects registered through multiple inheritance are
        // attached to the CLI tree but must not be deleted through this set.
        std::set<SubCommand*> childSubCommands;

        int requiredCount = 0;
        // Effective contribution counting stays in SubCommand because required(bool)
        // is a counted API and not every config child is owned in childSubCommands.
        // AppWithPtr derives/applies only the local effective CLI11 state from this base.
        int effectiveRequiredCount = 0;
        bool requiredForced = false;

        bool final;
    };

    template <typename ConcretSubCommand>
    inline SubCommand::SubCommand(SubCommand* parent, ConcretSubCommand* concretSubCommand, const std::string& group, bool final)
        : SubCommand(parent,
                     std::make_shared<utils::AppWithPtr>(
                         std::string(ConcretSubCommand::DESCRIPTION), std::string(ConcretSubCommand::NAME), concretSubCommand),
                     group,
                     final) {
    }

    template <typename NewSubCommand, typename... Args>
    NewSubCommand* SubCommand::newSubCommand(Args&&... args) {
        return !final ? dynamic_cast<NewSubCommand*>(*childSubCommands.insert(new NewSubCommand(this, std::forward(args)...)).first)
                      : nullptr;
    }

    template <typename RequestedSubCommand>
    RequestedSubCommand* SubCommand::getSubCommand() {
        auto* appWithPtr = subCommandApp->get_subcommand_no_throw(std::string(RequestedSubCommand::NAME));

        AppWithPtr* subCommandApp = nullptr;

        if (appWithPtr != nullptr) {
            subCommandApp = dynamic_cast<utils::AppWithPtr*>(appWithPtr);
        }

        return subCommandApp != nullptr ? dynamic_cast<RequestedSubCommand*>(subCommandApp->getPtr()) : nullptr;
    }

    template <typename RequestedSubCommand>
    RequestedSubCommand* SubCommand::getSubCommand() const {
        auto* appWithPtr = subCommandApp->get_subcommand_no_throw(std::string(RequestedSubCommand::NAME));

        AppWithPtr* subCommandApp = nullptr;

        if (appWithPtr != nullptr) {
            subCommandApp = dynamic_cast<utils::AppWithPtr*>(appWithPtr);
        }

        return subCommandApp != nullptr ? dynamic_cast<RequestedSubCommand*>(subCommandApp->getPtr()) : nullptr;
    }

    template <typename ValueTypeT>
    CLI::Option* SubCommand::addOption(const std::string& name,
                                       const std::string& description,
                                       const std::string& typeName,
                                       ValueTypeT defaultValue,
                                       const CLI::Validator& additionalValidator) const {
        return setDefaultValue(addOption(name, description, typeName, additionalValidator), defaultValue);
    }

    template <typename ValueTypeT>
    CLI::Option* SubCommand::addOptionVariable(const std::string& name,
                                               ValueTypeT& variable,
                                               const std::string& description,
                                               const std::string& typeName,
                                               const CLI::Validator& additionalValidator) const {
        return initialize(
            subCommandApp->add_option(name, variable, description), typeName, additionalValidator, !subCommandApp->get_disabled());
    }

    template <typename ValueTypeT>
    CLI::Option* SubCommand::addOptionVariable(const std::string& name,
                                               ValueTypeT& variable,
                                               const std::string& description,
                                               const std::string& typeName,
                                               ValueTypeT defaultValue,
                                               const CLI::Validator& additionalValidator) const {
        return setDefaultValue(addOptionVariable(name, variable, description, typeName, additionalValidator), defaultValue);
    }

    template <typename ValueTypeT>
    CLI::Option* SubCommand::addOptionFunction(const std::string& name,
                                               const std::function<void(const std::string&)>& callback,
                                               const std::string& description,
                                               const std::string& typeName,
                                               ValueTypeT defaultValue,
                                               const CLI::Validator& validator) const {
        return setDefaultValue(addOptionFunction(name, callback, description, typeName, validator), defaultValue);
    }

    template <typename ValueTypeT>
    CLI::Option* SubCommand::addFlag(const std::string& name,
                                     const std::string& description,
                                     const std::string& typeName,
                                     ValueTypeT defaultValue,
                                     const CLI::Validator& additionalValidator) const {
        return setDefaultValue(addFlag(name, description, typeName, additionalValidator), defaultValue);
    }

    template <typename ValueTypeT>
    CLI::Option* SubCommand::setDefaultValue(CLI::Option* option, const ValueTypeT& value, bool clear) const {
        try {
            option->default_val(value);

            if (clear) {
                option->clear();
            }
        } catch (const CLI::ParseError&) {
            option = nullptr;
        }

        return option;
    }

} // namespace utils

#endif // UTILS_SUBCOMMAND_H
